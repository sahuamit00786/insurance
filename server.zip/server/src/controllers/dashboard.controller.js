const { pool } = require('../config/db');
const { success } = require('../utils/response');

async function getStats(req, res) {
  const [[{ totalClients }]] = await pool.query('SELECT COUNT(*) AS totalClients FROM clients');
  const [[{ activeInsurance }]] = await pool.query(
    `SELECT COUNT(*) AS activeInsurance FROM insurances i
     JOIN lookup_values lv ON i.status_id = lv.id
     WHERE UPPER(lv.value) IN ('ACTIVE','IN-FORCE')`
  );
  const [[{ totalDocuments }]] = await pool.query('SELECT COUNT(*) AS totalDocuments FROM documents');
  const [[{ totalStaff }]] = await pool.query('SELECT COUNT(*) AS totalStaff FROM users WHERE status = "active"');

  return success(res, { totalClients, activeInsurance, totalDocuments, totalStaff });
}

async function getUpcomingBirthdays(req, res) {
  const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));

  const [rows] = await pool.query(
    `SELECT
       id,
       name,
       date_of_birth,
       phone,
       CASE
         WHEN STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d') >= CURDATE()
         THEN STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d')
         ELSE STR_TO_DATE(CONCAT(YEAR(CURDATE()) + 1, '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d')
       END AS next_birthday,
       DATEDIFF(
         CASE
           WHEN STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d') >= CURDATE()
           THEN STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d')
           ELSE STR_TO_DATE(CONCAT(YEAR(CURDATE()) + 1, '-', DATE_FORMAT(date_of_birth, '%m-%d')), '%Y-%m-%d')
         END,
         CURDATE()
       ) AS days_until_birthday
     FROM clients
     WHERE date_of_birth IS NOT NULL
     ORDER BY days_until_birthday ASC
     LIMIT ?`,
    [limit]
  );

  return success(res, rows);
}

async function getExpiry(req, res) {
  const { type = 'expiring', page = 1, limit = 10 } = req.query;
  const pageNum = Math.max(1, parseInt(page, 10) || 1);
  const limitNum = Math.min(50, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (pageNum - 1) * limitNum;

  const isExpired = type === 'expired';
  const dateFilter = isExpired
    ? 'i.premium_due_date < CURDATE()'
    : 'i.premium_due_date >= CURDATE()';
  const orderBy = isExpired
    ? 'i.premium_due_date DESC'
    : 'i.premium_due_date ASC';

  const baseFrom = `
    FROM insurances i
    JOIN clients c ON i.client_id = c.id
    LEFT JOIN lookup_values lv ON i.status_id = lv.id
    WHERE i.premium_due_date IS NOT NULL AND ${dateFilter}`;

  const [[{ total }]] = await pool.query(`SELECT COUNT(*) AS total ${baseFrom}`);

  const [rows] = await pool.query(
    `SELECT
       i.id, i.policy_no, c.id AS client_id, c.name AS client_name,
       i.premium_due_date AS due_date,
       DATEDIFF(i.premium_due_date, CURDATE()) AS days_until_expiry,
       lv.value AS status
     ${baseFrom}
     ORDER BY ${orderBy}
     LIMIT ? OFFSET ?`,
    [limitNum, offset]
  );

  return success(res, { rows, total, page: pageNum, limit: limitNum });
}

module.exports = { getStats, getUpcomingBirthdays, getExpiry };
